#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 2 ]]; then
    echo "usage: $0 RUN_NUMBER RENDERER" >&2
    exit 2
fi

readonly REMOTE_BASE="${SWIFTSPICE_DIRECT_REMOTE_BASE:?missing SWIFTSPICE_DIRECT_REMOTE_BASE}"
if [[ ! "$REMOTE_BASE" =~ ^/home/beribeli/swiftspice-remote-closure/direct-bb3b176-20260803-v1-(720|4k)$ ]]; then
    echo "unexpected remote fixture base" >&2
    exit 2
fi

ssh -o BatchMode=yes rocky8 \
    "SWIFTSPICE_PERF_BASE='$REMOTE_BASE' '$REMOTE_BASE/remote/boot-epoch.sh'"
