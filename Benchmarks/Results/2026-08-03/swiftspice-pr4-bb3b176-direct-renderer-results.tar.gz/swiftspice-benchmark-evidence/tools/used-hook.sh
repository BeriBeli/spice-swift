#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 3 ]]; then
    echo "usage: $0 before|after RUN_NUMBER RENDERER" >&2
    exit 2
fi

readonly PHASE="$1"
readonly RUN_NUMBER="$2"
readonly RENDERER="$3"
readonly REMOTE_BASE="${SWIFTSPICE_DIRECT_REMOTE_BASE:?missing SWIFTSPICE_DIRECT_REMOTE_BASE}"
readonly LOCAL_ROUND_DIRECTORY="${SWIFTSPICE_DIRECT_ROUND_DIRECTORY:?missing SWIFTSPICE_DIRECT_ROUND_DIRECTORY}"

if [[ ! "$REMOTE_BASE" =~ ^/home/beribeli/swiftspice-remote-closure/direct-bb3b176-20260803-v1-(720|4k)$ ]]; then
    echo "unexpected remote fixture base" >&2
    exit 2
fi
if [[ ! "$RUN_NUMBER" =~ ^[0-9]+$ ]] || [[ ! "$RENDERER" =~ ^[a-z0-9-]+$ ]]; then
    echo "invalid round identity" >&2
    exit 2
fi

LABEL="direct-pair-$(printf '%02d' "$RUN_NUMBER")-$RENDERER"
readonly LABEL

case "$PHASE" in
    before)
        ssh -o BatchMode=yes rocky8 \
            "SWIFTSPICE_PERF_BASE='$REMOTE_BASE' '$REMOTE_BASE/remote/round.sh' begin '$LABEL'" \
            >/dev/null
        if ! ssh -o BatchMode=yes rocky8 \
            "SWIFTSPICE_PERF_BASE='$REMOTE_BASE' '$REMOTE_BASE/remote/control.sh' reset" \
            >/dev/null
        then
            ssh -o BatchMode=yes rocky8 \
                "SWIFTSPICE_PERF_BASE='$REMOTE_BASE' '$REMOTE_BASE/remote/round.sh' end" \
                >/dev/null 2>&1 || true
            exit 1
        fi
        ;;
    after)
        ROUND_RESULT="$(ssh -o BatchMode=yes rocky8 \
            "SWIFTSPICE_PERF_BASE='$REMOTE_BASE' '$REMOTE_BASE/remote/round.sh' end" \
        )"
        readonly ROUND_RESULT
        ROUND_TOKEN="${ROUND_RESULT%% *}"
        ROUND_ID="${ROUND_TOKEN#round=}"
        readonly ROUND_TOKEN ROUND_ID
        if [[ ! "$ROUND_ID" =~ ^[0-9]{8}T[0-9]{6}Z-direct-pair-[0-9]{2}-[a-z0-9-]+$ ]] \
            || [[ "$ROUND_ID" != *"-$LABEL" ]]
        then
            echo "invalid or mismatched completed round ID" >&2
            exit 1
        fi
        RUN_ID="$(ssh -o BatchMode=yes rocky8 "cat '$REMOTE_BASE/state/current-run'")"
        readonly RUN_ID
        if [[ ! "$RUN_ID" =~ ^[0-9]{8}T[0-9]{6}Z$ ]]; then
            echo "invalid remote run ID" >&2
            exit 1
        fi
        mkdir -p "$LOCAL_ROUND_DIRECTORY"
        scp -q \
            "rocky8:$REMOTE_BASE/logs/$RUN_ID/rounds/$ROUND_ID-server.log" \
            "rocky8:$REMOTE_BASE/logs/$RUN_ID/rounds/$ROUND_ID-guest-telemetry.log" \
            "rocky8:$REMOTE_BASE/logs/$RUN_ID/rounds/$ROUND_ID-configuration.txt" \
            "rocky8:$REMOTE_BASE/logs/$RUN_ID/rounds/$ROUND_ID-versions.txt" \
            "$LOCAL_ROUND_DIRECTORY/"
        ;;
    *)
        echo "invalid hook phase: $PHASE" >&2
        exit 2
        ;;
esac
